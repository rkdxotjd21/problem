var id;
var pw;

window.onload = function () {
    id = document.getElementById("user-id");
    pw = document.getElementById("user-pw");
}

function Login(){
    var str="";
    str = "id:" + id.value + "\n" + "pw:" + pw.value;
    alert(str);
}
