var dice=Math.floor(Math.random() * 6 + 1);
document.write(dice + "<img src='../img/dice"+dice+".png'>");
