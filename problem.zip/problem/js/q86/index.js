//js
var btn;
var box;
var i=true;
window.onload = function(){
    btn = document.getElementById("btn");
    box = document.getElementById("box");
    btn.addEventListener("click",popup);
}

function popup(){
    if(i==true)
    {
        box.style.display = "inline";
       i=false;
    }
    else
    {
        box.style.display = "none";
        i=true;
    }
}


