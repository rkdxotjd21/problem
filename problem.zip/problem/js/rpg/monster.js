class Monster {
    constructor(name, MAX_HP, ATTACK_DAMAGE, money, EXP) {
        this.name = name;
        this.MAX_HP = MAX_HP;
        this.hp = MAX_HP;
        this.ATTACK_DAMAGE = ATTACK_DAMAGE;
        this.money = money;
        this.EXP = EXP;
    }

    GetName() {
        return this.name;
    }
    GetHp() {
        return this.hp;
    }
    GetMAX_HP() {
        return this.MAX_HP;
    }
    ReduceHp(damage) {
        if (this.hp <= damage) {
            this.hp = 0;
            return;
        }
        this.hp -= damage;
    }
    GetMoney() {
        return this.money;
    }
    GetEXP() {
        return this.EXP;
    }
    Info() {
        // dw('[' + this.name + '(' + this.hp + '/' + this.MAX_HP + ')' + ']');
        // td('[' + this.name + '(' + this.hp + '/' + this.MAX_HP + ')' + ']');
        td_m('[' + this.name + '(' + this.hp + '/' + this.MAX_HP + ')' + ']');tb_m();
    }
    Attack(User) {
        var damage;
        damage = Math.floor(Math.random() * this.ATTACK_DAMAGE + 1);
        User.ReduceHp(damage);
        // dw(this.name + "가 " + User.name + "를 " + damage + "만큼 공격");br();
        // td(this.name + "가 " + User.name + "를 " + damage + "만큼 공격");tb();
        td_m(this.name + "가 " + User.name + "를 " + damage + "만큼 공격");
    }
}