class User {
    constructor(name, MAX_HP, ATTACK_DAMAGE, money, LEVELUP_EXP) {
        this.name = name;
        this.MAX_HP = MAX_HP;
        this.hp = MAX_HP;
        this.ATTACK_DAMAGE = ATTACK_DAMAGE;
        this.money = money;
        this.LEVELUP_EXP = LEVELUP_EXP;
        this.exp = 0;
    }
    GetName() {
        return this.name;
    }
    GetHp() {
        return this.hp;
    }
    GetMAX_HP() {
        return this.MAX_HP;
    }
    ReduceHp(damage) {
        if (this.hp <= damage) {
            this.hp = 0;
            return;
        }
        this.hp -= damage;
    }
    GetATTACK_DAMAGE() {
        return this.ATTACK_DAMAGE;
    }
    GetMoney() {
        return this.money;
    }
    GetExp() {
        return this.exp;
    }
    GetLEVELUP_EXP() {
        return this.LEVELUP_EXP;
    }
    GainExp(exp) {
        this.exp += exp;
    }
    GainMoney(money) {
        this.money += money;
    }
    Info() {
        // dw('[' + this.name + '(' + this.hp + '/' + this.MAX_HP + ')' + "](EXP:" + this.exp + '/' + this.LEVELUP_EXP + ')');
        // td('[' + this.name + '(' + this.hp + '/' + this.MAX_HP + ')' + "](EXP:" + this.exp + '/' + this.LEVELUP_EXP + ')');
        td_u('[' + this.name + '(' + this.hp + '/' + this.MAX_HP + ')' + "](EXP:" + this.exp + '/' + this.LEVELUP_EXP + ')');tb_u();
    }
    Attack(Monster) {
        var damage;
        damage = Math.floor(Math.random() * this.GetATTACK_DAMAGE() + 1);
        Monster.ReduceHp(damage);
        // dw(this.name + "가 " + Monster.name + "를 " + damage + "만큼 공격");br();
        // td(this.name + "가 " + Monster.name + "를 " + damage + "만큼 공격");tb();
        td_u(this.name + "가 " + Monster.name + "를 " + damage + "만큼 공격");
    }
}