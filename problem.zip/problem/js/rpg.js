var str_u = "";
var str_m = "";
var str = "";
var user_Result;
var monster_Result;
var result;

window.onload = function () {
    user_Result = document.getElementById("user_result");
    monster_Result = document.getElementById("monster_result");
    result = document.getElementById("result");
}

function endl() {
    user_Result.scrollTop = user_Result.scrollHeight;
    monster_Result.scrollTop = monster_Result.scrollHeight;
    result.scrollTop = result.scrollHeight;
}

class battleHanlder {
    constructor(User, Monster) {
        this.User = User;
        this.Monster = Monster;
        this.turn = 0;
        this.UserDeath = false;
        this.MonsterDeath = false;
    }
    GetTurn() {
        return this.turn;
    }
    GetDeath() {
        if (this.MonsterDeath == true || this.UserDeath == true)
            return true;
        else
            return false;
    }
    ShowAllInfo() {
        // this.User.Info();this.Monster.Info();br();
        this.User.Info(); this.Monster.Info();
    }
    Fight() {
        if (this.turn == 0) {
            // hr(); dw("전투시작"); hr(); br();
            th(); td("전투시작"); th(); tb();
        }

        if (this.UserDeath == false && this.MonsterDeath == false) {
            this.User.Attack(this.Monster); tb_u();
            if (this.Monster.GetHp() > 0) { this.Monster.Attack(this.User); tb_m(); }
            this.turn++;

            if (this.User.hp <= 0 || this.Monster.hp <= 0) {
                if (this.Monster.hp <= 0) {
                    this.User.exp += this.Monster.EXP;
                    this.User.money += this.Monster.money;
                    // dw(this.Monster.name + "가 " + this.User.name + "에게 죽어서 " + this.User.name + "가 경험치 " + this.Monster.EXP + " 및 " + this.Monster.money + "G 획득");br();
                    td(this.User.name + "가 " + this.Monster.name + "를 죽여서 " + this.User.name + "가 경험치 " + this.Monster.EXP + " 및 " + this.Monster.money + "G 획득"); tb();
                    this.UserDeath = true;
                    this.ShowAllInfo();
                    th(); td("전투종료"); th(); tb();
                }
                else {
                    // dw(this.User.name + "가 " + this.Monster.name + "에게 죽음");br();
                    td(this.User.name + "가 " + this.Monster.name + "에게 죽음"); tb();
                    this.MonsterDeath = true;
                    this.ShowAllInfo();
                    th(); td("전투종료"); th(); tb();
                }
            }
        }
    }
}

var orc = new Monster("오크", 100, 20, 200, 100);
var elf = new User("엘프", 120, 15, 0, 300);
var battle = new battleHanlder(elf, orc);

function AutoClick() {

    while (true) {
        if (battle.GetDeath() == true)
            break;
        if (battle.GetTurn() == 0)
            battle.ShowAllInfo();
        battle.Fight();
    }
    endl();
}

function TurnClick() {
    if (battle.turn == 0)
        battle.ShowAllInfo();
    battle.Fight();
    endl();
}
