var dice = Math.floor(Math.random() * 6 + 1);
switch (dice) {
    case 1:
        document.write(dice + "<img src='../img/dice1.png'>");
        break;
    case 2:
        document.write(dice + "<img src='../img/dice2.png'>");
        break;
    case 3:
        document.write(dice + "<img src='../img/dice3.png'>");
        break;
    case 4:
        document.write(dice + "<img src='../img/dice4.png'>");
        break;
    case 5:
        document.write(dice + "<img src='../img/dice5.png'>");
        break;
    case 6:
        document.write(dice + "<img src='../img/dice6.png'>");
        break;
    default:
        document.write("잘못된 입력 발생" + "<br>");

}