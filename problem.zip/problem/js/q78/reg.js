var month;
var day;

window.onload=function(){
var str_m="";
var str_d="";

month=document.getElementById("birth_m");
day=document.getElementById("birth_d");

for(let i=1;i<13;i++)
{
    str_m+="<option value="+i+">"+i+"</option>";
}

for(let i=1;i<32;i++)
{
    str_d+="<option value="+i+">"+i+"</option>";
}
month.innerHTML=str_m;
day.innerHTML=str_d;
}

