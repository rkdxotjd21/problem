var com=new Array(6);
for(let i=0;i<6;i++)
{
    com[i]=Math.floor(Math.random()*45+1);
    dw(com[i]);
    br();
}

