for(var i=0;i<5;i++)
{
    document.write("<img src='../img/cat.jpg'>");
}