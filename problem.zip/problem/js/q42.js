function one(){
    return 100;
}
dw(one());
br();
function two(){
    return 200;
}
dw(two());
br();
function sum(a,b){
    return a+b;
}
dw(sum(100,200));
br();
dw(sum(one(),two()));