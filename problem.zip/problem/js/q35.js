var arr=new Array(3);
arr=["개","고양이","너굴맨"];
var str=arr[1]+arr[0];
alert(str);