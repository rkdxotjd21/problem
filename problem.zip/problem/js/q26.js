var cat_name;
var cat_species;
var cat_age;
var cat;
function cat(cat_name,cat_species,cat_age){
cat=cat_name+cat_species+cat_age;
return cat;
}
alert(cat("뽀삐","아프리카 고양이","10"));