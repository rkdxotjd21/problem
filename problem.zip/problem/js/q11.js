var num=100;
if(num>1)
alert("크다");