for(var i=0;i<10;i++){
    document.write(i+1+"<br>");
}