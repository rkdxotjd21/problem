//js
var btn;
var box;
var i = true;
var n=10;
window.onload = function () {
    btn = document.getElementById("btn");
    box = document.getElementById("box");
    btn.addEventListener("click", popup);
}

function popup() {
    var pop=document.getElementById("box");

    pop.style.width= "500px";
    pop.style.height= "500px";
    pop.style.background= "violet";
    pop.style.transitionProperty = "width, height, background";
    pop.style.transitionDuration = "2s";
}


