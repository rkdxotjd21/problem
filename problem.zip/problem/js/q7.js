for(var i=0;i<Math.floor(Math.random()*100+1);i++)
{
    if(i+1==7)
    {
        document.write(i+1+".<img id='gold' src='../img/cat.jpg'>");
    }
    else{
        document.write(i+1+".<img src='../img/cat.jpg'>");
    }
}