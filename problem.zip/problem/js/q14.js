var num = prompt("값을 입력:");
switch (num) {
    case "1":
        alert("1");
        break;
    case "2":
        alert("2");
        break;
    case "3":
        alert("3");
        break;
    default:
        alert("잘못된 값 입력");
        break;
}