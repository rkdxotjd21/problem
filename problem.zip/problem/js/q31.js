var text_input;
var user="";
var com="";
var result = "";

window.onload=function(){
    text_input=document.getElementById("user");  
}

function match() {
    com = Math.floor(Math.random() * 3 + 1);
    if(com==1)
    com="가위";
    else if(com==2)
    com="바위";
    else
    com="보";
    switch (user) {
        case "가위":
            if (com == "바위")
                result = "lose";
            else if (com == "가위")
                result = "draw";
            else
                result = "win";
            break;
        case "바위":
            if (com == "바위")
            result = "draw";
        else if (com == "가위")
            result = "win";
        else
            result = "lose";
            break;
        case "보":
            if (com == "바위")
            result = "win";
        else if (com == "가위")
            result = "lose";
        else
            result = "draw";
            break;
    }
    dw("유저:"+user);
    br();
    dw("컴퓨터:"+com);
    br();
    dw("결과:"+result);
}

function ButtonClick(){
    
    while (true) {
        user=text_input.value;
        if ((user == "가위" || user == "바위" | user == "보"))
        {
            match();
            break;
        }
        else{
            alert("다시 입력하세요");
            break;
        }
    }

}