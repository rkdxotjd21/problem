//HanlderClass
//EntityClass
class Monster {
    #name;
    #MAX_HP;
    #EXP;
    #ATTACK_DAMAGE;
    #hp;
    constructor(name, MAX_HP, ATTACK_DAMAGE,EXP) {
        this.#name = name;
        this.#MAX_HP = MAX_HP;
        this.#hp=MAX_HP;
        this.#ATTACK_DAMAGE = ATTACK_DAMAGE;
        this.#EXP=EXP;
    }
    ShowInfo() {
        dw('[' + this.#name + ':(체력:' + this.#hp + '/' + this.#MAX_HP + '),(공격력:' + this.#ATTACK_DAMAGE + ")]");
    }
    GetName(){
        return this.#name;
    }
    GetMAX_HP(){
        return this.#MAX_HP;
    }
    GetHp(){
        return this.#hp;
    }
    GetATTACK_DAMAGE(){
        return this.#ATTACK_DAMAGE;
    }
    GetEXP(){
        return this.#EXP;
    }
    DropItem(){
        var num=Math.floor(Math.random()*6+1);
        switch(num){
            case 1:var dragonBow=new Weapon("용의 활",40);
            dw("드롭 아이템:");dragonBow.ShowInfo();
            return dragonBow;
            break;
            case 2:var longsword=new Weapon("롱소드",20);
            dw("드롭 아이템:");longsword.ShowInfo();
            return longsword;
            break;
            case 3:var elfbow=new Weapon("엘프의 활",30);
            dw("드롭 아이템:");elfbow.ShowInfo();
            return elfbow;
            break;
            case 4:var lightVest=new Armor("가죽 조끼",30);
            dw("드롭 아이템:");lightVest.ShowInfo();
            return lightVest;
            break;
            case 5:var ironAromor=new Armor("철 갑옷",40);
            dw("드롭 아이템:");ironAromor.ShowInfo();
            return ironAromor;
            break;
            default:dw("드롭된 아이템이 없습니다.");
            break;
        }
    }

    Attack(){
    }
}

// var orc=new Monster("오크",120,20,100);


