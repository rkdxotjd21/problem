class Cat{
    name="뽀삐";
    age=10;
    species="아프리카 고양이";
}
var kitty= new Cat();
kitty.name="야옹이";
dw(kitty.name);
br();
dw(kitty.age);
br();
dw(kitty.species);