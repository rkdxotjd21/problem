class Cat{
    name="뽀삐";
    age=10;
    species="아프리카 고양이";
}
var kitty= new Cat();
kitty.name="야옹이";
kitty.age=5;
kitty.species="샤브로 고양이";
dw(kitty.name);
br();
dw(kitty.age);
br();
dw(kitty.species);