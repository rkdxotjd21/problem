class Cat{
    name="뽀삐";
    age=10;
    species="아프리카 고양이";
    constructor(name,age,species){
        this.name=name;
        this.age=age;
        this.species=species;
    }
    crying(){
        dw("야옹~~~");
        br();
    }
}
var kitty= new Cat();
kitty.name="야옹이";
kitty.age=5;
kitty.species="샤브로 고양이";
var yaongi= new Cat("망치",15,"들고양이")
if(yaongi.age>kitty.age)
{
    dw("형님 고양이:"+yaongi.name);

    br();
    dw("동생 고양이:"+kitty.name);
}
else if(yaongi.age<kitty.age){
    dw("형님 고양이:"+kitty.name);
    br();
    dw("동생 고양이:"+yaongi.name);
}
else{
    dw("둘은 친구임");
}
br();
dw(yaongi.name+":");
yaongi.crying();
dw(kitty.name+":");
kitty.crying();