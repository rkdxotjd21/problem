//HanlderClass
//EntityClass
class Human {
    #Base;
    #Armor;
    #Weapon;
    constructor(Base, Armor, Weapon) {
        this.#Base = Base;
        this.#Armor = Armor;
        this.#Weapon = Weapon;
    }
    ShowInfo() {
        dw('[' + this.#Base.GetName() + ':(체력:' + (this.#Base.GetHp() + this.#Armor.GetMAX_HP()) + '/' + (this.#Base.GetMAX_HP() + this.#Armor.GetMAX_HP()) + '),(공격력:' + (this.#Base.GetATTACK_DAMAGE() + this.#Weapon.GetATTACK_DAMAGE()) + ")](EXP:" + this.#Base.GetExp() + '/' + this.#Base.GetLEVELUP_Exp() + ')');
    }
    ShowInventory() {
        dw("[인벤토리]"); br();
        dw("무기:"); this.#Armor.ShowInfo(); br();
        dw("방어구:"); this.#Weapon.ShowInfo(); br();
    }
    UnEquipArmor() {
        if (this.#Armor.GetMAX_HP() != 0)
            this.#Armor = new Armor("", 0);
    }
    UnEquipWeapon() {
        if (this.#Weapon.GetATTACK_DAMAGE() != 0)
            this.#Weapon = new Weapon("", 0);
    }
    EquipArmor(Armor) {
        this.#Armor = Armor;
    }
}
class Base {
    #name;
    #MAX_HP;
    #exp = 0;
    #LEVELUP_EXP = 300;
    #ATTACK_DAMAGE;
    #hp;
    constructor(name, MAX_HP, ATTACK_DAMAGE) {
        this.#name = name;
        this.#MAX_HP = MAX_HP;
        this.#hp = MAX_HP;
        this.#ATTACK_DAMAGE = ATTACK_DAMAGE;
    }
    ShowInfo() {
        dw('[' + this.#name + ':(체력:' + this.#hp + '/' + this.#MAX_HP + '),(공격력:' + this.#ATTACK_DAMAGE + ")](EXP:" + this.#exp + '/' + this.#LEVELUP_EXP + ')');
    }
    GetName() {
        return this.#name;
    }
    GetMAX_HP() {
        return this.#MAX_HP;
    }
    GetHp() {
        return this.#hp;
    }
    GetATTACK_DAMAGE() {
        return this.#ATTACK_DAMAGE;
    }
    GetExp() {
        return this.#exp;
    }
    GetLEVELUP_Exp() {
        return this.#LEVELUP_EXP;
    }
}
class Armor {
    #name;
    #MAX_HP;
    constructor(name, MAX_HP) {
        this.#name = name;
        this.#MAX_HP = MAX_HP;
    }
    ShowInfo() {
        dw('[' + this.#name + '/' + "최대 체력 증가:" + this.#MAX_HP + ']');
    }
    GetMAX_HP() {
        return this.#MAX_HP;
    }
}
class Weapon {
    #name;
    #ATTACK_DAMAGE;
    constructor(name, ATTACK_DAMAGE) {
        this.#name = name;
        this.#ATTACK_DAMAGE = ATTACK_DAMAGE;
    }
    ShowInfo() {
        dw('[' + this.#name + '/' + "공격력 증가:" + this.#ATTACK_DAMAGE + ']');
    }
    GetATTACK_DAMAGE() {
        return this.#ATTACK_DAMAGE;
    }
}
var human = new Base("궁수", 100, 5);
human.ShowInfo();
br();
var archer = new Human(human, new Armor("기본 조끼", 20), new Weapon("기본 활", 10));
archer.ShowInfo();
archer.ShowInventory();
br();
archer.UnEquipArmor();
archer.UnEquipWeapon();
archer.ShowInfo();
archer.ShowInventory();


