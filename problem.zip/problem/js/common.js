function hr() {
    document.write("<hr>");
}
function br() {
    document.write("<br>");
}
function dw(s) {
    document.write(s);
}

function td(s_t) {
    str += s_t;
    result.value = str;
}
function tb() {
    str += "\n";
    result.value = str;
}
function th() {
    str += "========================";
    result.value = str;
}

///////////////////////
function td_u(s_u) {
    str_u += s_u;
    user_Result.value = str_u;
}
function tb_u() {
    str_u += "\n";
    user_Result.value = str_u;
}
function th_u() {
    str_u += "========================";
    user_Result.value = str_u;
}
//////////////////////////

function td_m(s_m) {
    str_m += s_m;
    monster_Result.value = str_m;
}
function tb_m() {
    str_m += "\n";
    monster_Result.value = str_m;
}
function th_m() {
    str_m += "========================";
    monster_Result.value = str_m;
}