function addCatAndInputText(){
var str=prompt("문자열 입력:");
str+="고양이";
alert(str);
}
addCatAndInputText();