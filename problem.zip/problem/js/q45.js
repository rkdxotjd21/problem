class Cat{
    name="뽀삐";
    age=10;
    species="아프리카 고양이";
}
new Cat();
dw(Cat.name);
br();
dw(Cat.age);
br();
dw(Cat.species);