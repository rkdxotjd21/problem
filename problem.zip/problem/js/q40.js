var user = new Array(6);
var com = new Array(6);
var cnt = 0;

for (let i = 0; i < 6; i++) {
    com[i] = Math.floor(Math.random() * 45 + 1);
    for (let j = 0; j < i; j++) {
        if (com[j] == com[i]) {
            com[i] = Math.floor(Math.random() * 45 + 1);
            j = 0;
        }
    }
}


for (let i = 0; i < 6; i++) {
    user[i] = prompt(i + 1 + "번째 값 입력:");
    if (user[i] < 1 || user[i] > 45) {
        alert("잘못된 번호 입력");
        i--;
        continue;
    }

    for (let j = 0; j < i; j++) {
        if (user[j] == user[i]) {
            alert("같은 번호를 입력");
            i--;
            break;
        }
    }
}

dw("로또 번호:");
for (let i = 0; i < 6; i++) {
    dw(com[i] + " ");
}br();

dw("구매 번호:");
for (let i = 0; i < 6; i++) {
    dw(user[i] + " ");
}br();

for (let i = 0; i < 6; i++) {
    for (let j = 0; j < 6; j++) {
        if (com[i] == user[j])
            cnt++;
    }
}
switch (cnt) {
    case 3:
        dw("5등입니다");
        break;
    case 4:
        dw("4등입니다");
        break;
    case 5:
        dw("3등입니다");
        break;
    case 6:
        dw("1등입니다");
        break;
    default:
        dw("꽝입니다");
        break;

}


