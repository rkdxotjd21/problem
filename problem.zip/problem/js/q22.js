var cat_name="뽀삐";
var cat_species="아프리카 고양이";
var cat_age=10;
var cat="이름:"+cat_name+", 종류:"+cat_specie+", 나이:"+cat_age;
alert(cat);