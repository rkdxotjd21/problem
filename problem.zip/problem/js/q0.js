alert("헬로월드!!!");   
alert(1000);   
alert(1+7);   
