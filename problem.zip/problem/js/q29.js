var user;
var com;
var result = "";
function match() {
    com = Math.floor(Math.random() * 3 + 1);
    if(com==1)
    com="가위";
    else if(com==2)
    com="바위";
    else
    com="보";

    switch (user) {
        case "가위":
            if (com == "바위")
                result = "lose";
            else if (com == "가위")
                result = "draw";
            else
                result = "win";
            break;
        case "바위":
            if (com == "바위")
            result = "draw";
        else if (com == "가위")
            result = "win";
        else
            result = "lose";
            break;
        case "보":
            if (com == "바위")
            result = "win";
        else if (com == "가위")
            result = "lose";
        else
            result ="draw";
            break;
    }
    document.write("유저:"+user);
    br();
    document.write("컴퓨터:"+com);
    br();
    document.write("결과:"+result);
}


while (true) {
    user = prompt("가위,바위,보 입력:");
    if ((user == "가위" || user == "바위" | user == "보"))
    {
        match();
        break;
    }
    alert("다시 입력하세요");
}