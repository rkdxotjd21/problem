var text_input;
var result_output;
var user_image;
var com_image;
var user = "";
var com = "";
var result = "";
var screen = "";

window.onload = function () {
    text_input = document.getElementById("user");
    result_output = document.getElementById("result");
    user_image = document.getElementById("user_img");
    com_image = document.getElementById("com_img");
}

function match() {
    com = Math.floor(Math.random() * 3 + 1);
    if (com == 1) {
        com = "가위";
        com_image.innerHTML = "<img src='../img/com_scissor.png'>";
    }

    else if (com == 2) {
        com = "바위";
        com_image.innerHTML = "<img src='../img/com_rock.png'>";
    }
    else {
        com = "보";
        com_image.innerHTML = "<img src='../img/com_paper.png'>";
    }
    if (user == "가위")
        user_image.innerHTML = "<img src='../img/scissor.png'>";
    else if (user == "바위")
        user_image.innerHTML = "<img src='../img/rock.png'>";
    else
        user_image.innerHTML = "<img src='../img/paper.png'>";
    switch (user) {
        case "가위":
            if (com == "바위")
                result = "lose";
            else if (com == "가위")
                result = "draw";
            else
                result = "win";
            break;
        case "바위":
            if (com == "바위")
                result = "draw";
            else if (com == "가위")
                result = "win";
            else
                result = "lose";
            break;
        case "보":
            if (com == "바위")
                result = "win";
            else if (com == "가위")
                result = "lose";
            else
                result = "draw";
            break;
    }
    screen = "유저:" + user + "\n" + "컴퓨터:" + com + "\n" + "결과:" + result;
    result_output.value = screen;
}

function ButtonClick() {

    while (true) {
        user = text_input.value;
        if ((user == "가위" || user == "바위" | user == "보")) {
            match();
            break;
        }
        else {
            alert("다시 입력하세요");
            break;
        }
    }

}