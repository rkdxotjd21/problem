var a=5
function one(a){
    return a+1;
}
dw(one(7));
br();
dw(one(one(7)));
