var num=prompt("값을 입력:");
if(num>100)
alert("100보다 큽니다.");
else if(num<100)
alert("100보다 작습니다.");
else
alert("100입니다.")
