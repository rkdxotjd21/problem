window.onload=function(){
    var id=document.getElementById("a");
    var num="";
    while(true){

        num=prompt("값 입력:");
        if(num==100)
        {
            break;
        }
        else{
            id.innerHTML="입력 값:"+num;
        }
    }
}