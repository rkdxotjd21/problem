var id;
var pw;

window.onload = function () {
    id = document.getElementById("user-id");
    pw = document.getElementById("user-pw");
}

function Login() {
    var str = "";
    if (id.value == "cat" && pw.value == "1234") {
        str = "id:" + id.value + "\n" + "pw:" + pw.value;
        alert("로그인 성공");
    }
    else
        alert("로그인 실패");
}
