//js
var btn;
var imgCat;
var i=true;
window.onload = function(){
    btn = document.getElementById("btn");
    imgCat = document.getElementById("cat");
    btn.addEventListener("click",popup);
}

function popup(){
    if(i==true)
    {
        imgCat.style.display = "inline";
       i=false;
    }
    else
    {
        imgCat.style.display = "none";
        i=true;
    }
}


