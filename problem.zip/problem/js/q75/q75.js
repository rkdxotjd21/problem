var id;
var pw;

window.onload = function () {
    id = document.getElementById("user-id");
    pw = document.getElementById("user-pw");
}

function Login() {
    if (id.value == "cat" && pw.value == "1234") {
        alert("로그인 성공");
    }
    else
        alert("로그인 실패");
}
