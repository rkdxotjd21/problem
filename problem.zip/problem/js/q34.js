var arr=new Array(1,2,3,4);
var num=arr[1]+arr[3]
alert(num);