for (let i = 0; i++< 10; ) {

    for (let k = i; k < 10; k++)
        document.write('_');
    for (let j = 0; j < i; j++)
        document.write('*');

    document.write("<br>");
}