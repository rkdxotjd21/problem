var a,b,c,d,e,f;
a=2;
b=1;
c=3;
d=4;
e=100;
f=99;
if((a>b&&c<d)||(e==100&&f!=100))
{
    document.write("고양이");
}


