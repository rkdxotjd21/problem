var user=new Array(6);
var com=new Array(6);
var cnt=0;
for(let i=0;i<6;i++)
{
    com[i]=Math.floor(Math.random()*45+1);
}

for(let i=0;i<6;i++)
{
    user[i]=prompt(i+1+"번째 값 입력:");
}
dw("로또 번호:");
for(let i=0;i<6;i++)
{
dw(user[i]+" ");
}
for(let i=0;i<6;i++)
{
    for(let j=0;j<6;j++)
    {
        if(com[i]==user[j])
        cnt++;
    }
}
br();
dw("일치번호 개수:"+cnt);

