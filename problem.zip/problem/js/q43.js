var a=5
function one(a){
    return a+1;
}
dw(one(a));
br();
dw(one(100));