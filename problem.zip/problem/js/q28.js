for(let i=1;i<=10;i++){
    if((i%2)==0){
        document.write(i+"는 짝수입니다.");
        br();
    }
    else{
        document.write(i+"는 홀수입니다.");
        br();
    }
   
}