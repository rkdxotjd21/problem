var num=0;
while(++num<=10){
    document.write(num+"<br>");
}