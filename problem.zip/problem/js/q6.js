for(var i=0;i<Math.floor(Math.random()*100+1);i++)
{
    document.write(i+1+".<img src='../img/cat.jpg'>");
}