var num=Math.floor(Math.random()*10+1);
for(let i=1;i<=10;i++){
    if(i==num)
    break;
    document.write(i+"<br>");
}